import sys
import boto3


def post_messages(session, shoot_numbers):
    sns = session.resource("sns")
    topic = sns.Topic("arn:aws:sns:eu-west-1:404315009621:transfer-shoots-staging")
    for shoot_number in shoot_numbers:
        topic.publish(Message=shoot_number.strip())


if __name__ == "__main__":
    post_messages(boto3.Session(), sys.stdin.readlines())
